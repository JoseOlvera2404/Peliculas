package com.example.peliculasapp;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class MoviesActivity extends AppCompatActivity {

    ListView moviesListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies);

        moviesListView = findViewById(R.id.moviesListView);

        // Aquí se puede llenar la lista con las películas activas
        // Crear un adaptador para mostrar la lista de películas
    }
}

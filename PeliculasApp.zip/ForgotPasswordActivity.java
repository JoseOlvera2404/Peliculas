package com.example.peliculasapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.emailjs.sdk.EmailJS;

public class ForgotPasswordActivity extends AppCompatActivity {

    EditText emailEditText;
    Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailEditText = findViewById(R.id.emailEditText);
        sendButton = findViewById(R.id.sendButton);

        sendButton.setOnClickListener(view -> {
            String email = emailEditText.getText().toString();
            if (!email.isEmpty()) {
                sendEmail(email);
            } else {
                Toast.makeText(ForgotPasswordActivity.this, "Por favor, ingresa tu correo", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendEmail(String email) {
        EmailJS emailJS = new EmailJS("YOUR_USER_ID", "YOUR_SERVICE_ID");
        emailJS.send("template_qtbe27f", email, new EmailJS.Callback() {
            @Override
            public void onSuccess() {
                Toast.makeText(ForgotPasswordActivity.this, "Correo enviado", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Exception e) {
                Toast.makeText(ForgotPasswordActivity.this, "Error al enviar el correo", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
